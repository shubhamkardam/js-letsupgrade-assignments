let age = prompt("Ehat is your age??","type here");
console.log(age);