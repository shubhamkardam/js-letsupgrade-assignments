var a = confirm("are you above 18?? ok for yes & cancel for no");

if(a){
    alert("you can drink")
    console.log("you can drink")
}else{
    alert("you can not drink")
    console.log("you can drink")
}