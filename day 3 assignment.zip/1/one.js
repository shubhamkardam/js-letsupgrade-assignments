let num = prompt("Enter any number","type here");
console.log(Number(num));

		if(num%2 == 0){
    			output = `The number entered is ${num} and Number is even.`
			console.log(output);
			
		}else{   
			output = `The number entered is ${num} and Number is odd.`
			console.log(output);
			
		     }
		
  	