let name = prompt("Enter your OS","type here");
let ver = prompt("Enter your version","type here");

console.log(name + " " + ver);
   
output = `The OS name is ${name} and version is ${ver}.`
console.log(output);
	   		

		
  	