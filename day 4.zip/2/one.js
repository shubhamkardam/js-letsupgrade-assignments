const student = {
    name : "Helsinki",
    age : 24,
    projects:{
        dicegame:"two player dice game takes java script"
    }
}

const {name:a,age:b,projects:{dicegame:c}} = student

console.log(a)
console.log(b)
console.log(c)