const shoppingList = ["rice","wheat","bread","butter"]

console.log(`shopping-list: ${shoppingList}`)

const shoppingBasket = [...shoppingList,"maggie","cold-drink"]

console.log(`shopping-Basket: ${shoppingBasket}`)