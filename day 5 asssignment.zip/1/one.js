var num = prompt("enter a positive number here","type here");
var arr = [];
for(i=0;i<num;i++){
    arr[i]= i+1;
}
console.log(arr);

let odd = arr.filter(el => el%2!=0);
console.log(odd)

let cube = odd.map(el => el**3)
console.log(cube)