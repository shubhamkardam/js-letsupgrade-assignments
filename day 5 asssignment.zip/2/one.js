class User {
    constructor(name, age,email) {
      this.name = name;
      this.age = age;
      this.email = email;
      this.luCoins = 0;
      this.courses = [];
    }


    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
    addCoins(){
        this.luCoins++;
        console.log(`${this.name} has ${this.luCoins} coins`);
        return this;
    }
    getDetails(){
        console.log(`Name is ${this.name}, email is ${this.email}`);
        return this;
    }

}


class Moderator extends User{
    constructor(name,age,email){
        super(name,age,email);
        

    }
    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
    addCoins(){
        this.lucoins++;
        console.log(`${this.name} has ${this.lucoins} coins`);
        return this;
    }
    removecoing(){
        this.lucoins--;
        console.log(`${this.name} has removed one coin so now moderator has ${this.lucoins} coins`);
        return this;
    }
}

let moderator1 = new Moderator('mmm[MODERATOR]',27,'mmm@gmail.com')
moderator1.login().addCoins().addCoins().removecoing().addCoins().logout();

class Admin extends Moderator{
    addCourses(user,course){
        user.courses.push(course);
        console.log(user);
    }
} 

let user1 = new User('shubham',25,'shubham@gmail.com');
let user2 = new User('someone',26,'someone@gmail.com');



let mod = new Moderator('Berlin',24,'b@gmail.com','Moderator');
let admin = new Admin('Rio',25,'r@gmail.com');
let users = [user1,user2,mod,admin];

users.forEach(element => {
    console.log(element);
});


users.forEach(element => {
    console.log(element);
});

admin.addCourses(user1,'Javascript');
admin.addCourses(user2,'Python');