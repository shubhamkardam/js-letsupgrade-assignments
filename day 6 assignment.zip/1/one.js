var c = ["#1B262C", "#0F4C75", "#3282B8", "#BBE1FA"];

  function changeColor() {
    setTimeout(function loop() {
      document.bgColor = c.shift();
      if (c.length) {
        setTimeout(loop, 5000);
      }
    }, 5000);
  }

  function start() {
    setInterval(changeColor(), 20000);
  }