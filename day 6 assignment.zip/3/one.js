const name = prompt("Enter your name","Anonymous");
document.getElementById('title').innerText = `Welcome to the website ${name}`;

const ctime = document.getElementById('time');

function clock(){
    let date = new Date();
    let time = date.toLocaleTimeString();
    ctime.innerText = time;
}

setInterval(clock,1000);