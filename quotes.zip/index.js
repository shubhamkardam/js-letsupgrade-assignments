let btn = document.getElementById('btn');
let output = document.getElementById('output');
let quotes = ['"The greatest glory in living lies not in never falling, but in rising every time we fall." -Nelson Mandela',
'"The way to get started is to quit talking and begin doing." -Walt Disney',
'"If life were predictable it would cease to be life, and be without flavor." -Eleanor Roosevelt',
'"Life is what happens when you are busy making other plans." -John Lennon',
'"Spread love everywhere you go. Let no one ever come to you without leaving happier." -Mother Teresa',
'"When you reach the end of your rope, tie a knot in it and hang on." -Franklin D. Roosevelt',
'"Always remember that you are absolutely unique. Just like everyone else." -Margaret Mead',
'"The future belongs to those who believe in the beauty of their dreams." -Eleanor Roosevelt'
];

btn.addEventListener('click',function(){
    var randomquote = quotes[Math.floor(Math.random()*quotes.length)];
    output.innerHTML = randomquote;
})
